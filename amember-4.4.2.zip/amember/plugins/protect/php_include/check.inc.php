<?php
include(dirname(__FILE__)."/../../../library/Am/Lite.php");
Am_Lite::getInstance()->checkAccess($_product_id);